# Riddle_me_this
A short game of riddles built in Jac with a LLM integration that will generate a random riddle, you try to answer, and it tells you if you’re right or gives a witty hint.
Its basically an improvement of the guessing game with riddles being issued andyou get three guesses.
